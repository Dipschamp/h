# YT-Django-Simple-Blog-App-Part10-User-Favourties-Save
 
